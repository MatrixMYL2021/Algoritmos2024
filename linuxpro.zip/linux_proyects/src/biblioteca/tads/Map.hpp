#ifndef MAP_HPP
#define MAP_HPP

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

// Estructura del TAD Map
template<typename K, typename V>
struct Map {
    vector<pair<K, V>> data; // Utilizamos un vector de pares para almacenar las claves y valores
    int current; // Variable para el control de iteración

    Map() : current(0) {} // Constructor que inicializa la variable de iteración

    // Función para crear un nuevo mapa vacío
    void map() {
        data.clear();
        current = 0;
    }

    // Función para obtener el valor asociado a una clave
    V* mapGet(const K& key) {
        for (auto& entry : data) {
            if (entry.first == key) {
                return &entry.second;
            }
        }
        return nullptr;
    }

    // Función para insertar o actualizar un elemento en el mapa
    void mapPut(const K& key, const V& value) {
        for (auto& entry : data) {
            if (entry.first == key) {
                entry.second = value;
                return;
            }
        }
        data.push_back(make_pair(key, value));
    }

    // Función para verificar si una clave existe en el mapa
    bool mapContains(const K& key) {
        for (const auto& entry : data) {
            if (entry.first == key) {
                return true;
            }
        }
        return false;
    }

    // Función para remover un elemento del mapa
    void mapRemove(const K& key) {
        for (auto it = data.begin(); it != data.end(); ++it) {
            if (it->first == key) {
                data.erase(it);
                return;
            }
        }
    }

    // Función para remover todos los elementos del mapa
    void mapRemoveAll() {
        data.clear();
    }

    // Función para obtener el tamaño del mapa
    int mapSize() const {
        return data.size();
    }

    // Función para verificar si hay más elementos en la iteración
    bool mapHasNext() {
        return current < data.size();
    }

    // Función para obtener la siguiente clave en la iteración
    K mapNextKey() {
        if (mapHasNext()) {
            return data[current++].first;
        }
        throw out_of_range("No more keys in map");
    }

    // Función para obtener el siguiente valor en la iteración
    V* mapNextValue() {
        if (mapHasNext()) {
            return &data[current++].second;
        }
        throw out_of_range("No more values in map");
    }

    // Función para reiniciar la iteración del mapa
    void mapReset() {
        current = 0;
    }

    // Función para descubrir si una clave existe y obtener su valor
    bool mapDiscover(const K& key, V& value) {
        for (const auto& entry : data) {
            if (entry.first == key) {
                value = entry.second;
                return true;
            }
        }
        return false;
    }

    // Función para ordenar el mapa por claves
    void mapSortByKeys() {
        sort(data.begin(), data.end(), [](const pair<K, V>& a, const pair<K, V>& b) {
            return a.first < b.first;
        });
    }

    // Función para ordenar el mapa por valores
    void mapSortByValues() {
        sort(data.begin(), data.end(), [](const pair<K, V>& a, const pair<K, V>& b) {
            return a.second < b.second;
        });
    }
};

#endif // MAP_HPP
