#ifndef ARRAYS_HPP
#define ARRAYS_HPP

#include <iostream>
using namespace std;

// Función add
template<typename T>
int add(T arr[], int& len, T e) {
    arr[len] = e;
    len++;
    return len - 1;
}

// Función insert
template<typename T>
void insert(T arr[], int& len, T e, int p) {
    for (int i = len; i > p; i--) {
        arr[i] = arr[i-1];
    }
    arr[p] = e;
    len++;
}

// Función remove
template<typename T>
T remove(T arr[], int& len, int p) {
    T removed = arr[p];
    for (int i = p; i < len - 1; i++) {
        arr[i] = arr[i + 1];
    }
    len--;
    return removed;
}

// Función find
template<typename T, typename K>
int find(T arr[], int len, K key, int cmpTK(T, K)) {
    for (int i = 0; i < len; i++) {
        if (cmpTK(arr[i], key) == 0) {
            return i;
        }
    }
    return -1; // No encontrado
}

// Función orderedInsert
template<typename T>
int orderedInsert(T arr[], int& len, T e, int cmpTT(T, T)) {
    int pos = 0;
    while (pos < len && cmpTT(arr[pos], e) < 0) {
        pos++;
    }
    insert(arr, len, e, pos);
    return pos;
}

// Función sort
template<typename T>
void sort(T arr[], int len, int cmpTT(T, T)) {
    for (int i = 0; i < len - 1; i++) {
        for (int j = i + 1; j < len; j++) {
            if (cmpTT(arr[i], arr[j]) > 0) {
                T temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
}

#endif // ARRAYS_HPP
