#include <iostream>
#include <map>
#include <tuple>
//#include "biblioteca/funciones/files.hpp"
//#include "biblioteca/funciones/arrays.hpp"
//#include "biblioteca/funciones/strings.hpp"
//#include "biblioteca/funciones/tokens.hpp"
//#include "biblioteca/tads/Arrays.hpp"
//#include "biblioteca/tads/colldiscord.hpp"
//#include "biblioteca/tads/Map.hpp"

using namespace std;

int main(){

	/*map<int,tuple<string,int>>Equipos;

	Equipos[1]= make_tuple("REAL MADRID",87);
	//Equipos[2]= make_tuple("BARCELONA",78);
	//Equipos[3]= make_tuple("LIVERPOOL",81);
	//Equipos[4]= make_tuple("PSG",69);

	
	cout<<"Equipo : "<<get<0>(Equipos[1])<<endl;
	cout<<"Puntos: "<<get<1>(Equipos[1])<<endl;
	*/


	return 0;
}


