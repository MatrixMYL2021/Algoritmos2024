#ifndef ARRAY_HPP
#define ARRAY_HPP

#include <iostream>
using namespace std;

// Estructura del TAD Array
template<typename T>
struct Array {
    T* data;
    int size;
    int capacity;
};

// Función array
template<typename T>
Array<T> array(int initialCapacity = 10) {
    Array<T> arr;
    arr.data = new T[initialCapacity];
    arr.size = 0;
    arr.capacity = initialCapacity;
    return arr;
}

// Función arrayAdd
template<typename T>
int arrayAdd(Array<T>& arr, T t) {
    if (arr.size == arr.capacity) {
        arr.capacity *= 2;
        T* newData = new T[arr.capacity];
        for (int i = 0; i < arr.size; i++) {
            newData[i] = arr.data[i];
        }
        delete[] arr.data;
        arr.data = newData;
    }
    arr.data[arr.size] = t;
    arr.size++;
    return arr.size - 1;
}

// Función arrayGet
template<typename T>
T arrayGet(Array<T>& arr, int pos) {
    return arr.data[pos];
}

// Función arraySet
template<typename T>
void arraySet(Array<T>& arr, int pos, T t) {
    arr.data[pos] = t;
}

// Función arrayInsert
template<typename T>
void arrayInsert(Array<T>& arr, T t, int pos) {
    if (arr.size == arr.capacity) {
        arr.capacity *= 2;
        T* newData = new T[arr.capacity];
        for (int i = 0; i < arr.size; i++) {
            newData[i] = arr.data[i];
        }
        delete[] arr.data;
        arr.data = newData;
    }
    for (int i = arr.size; i > pos; i--) {
        arr.data[i] = arr.data[i - 1];
    }
    arr.data[pos] = t;
    arr.size++;
}

// Función arraySize
template<typename T>
int arraySize(Array<T>& arr) {
    return arr.size;
}

// Función arrayRemove
template<typename T>
T arrayRemove(Array<T>& arr, int pos) {
    T removed = arr.data[pos];
    for (int i = pos; i < arr.size - 1; i++) {
        arr.data[i] = arr.data[i + 1];
    }
    arr.size--;
    return removed;
}

// Función arrayRemoveAll
template<typename T>
void arrayRemoveAll(Array<T>& arr) {
    arr.size = 0;
}

// Función arrayFind
template<typename T, typename K>
int arrayFind(Array<T>& arr, K key, int cmpTK(T, K)) {
    for (int i = 0; i < arr.size; i++) {
        if (cmpTK(arr.data[i], key) == 0) {
            return i;
        }
    }
    return -1; // No encontrado
}

// Función arrayOrderedInsert
template<typename T>
int arrayOrderedInsert(Array<T>& arr, T t, int cmpTT(T, T)) {
    int pos = 0;
    while (pos < arr.size && cmpTT(arr.data[pos], t) < 0) {
        pos++;
    }
    arrayInsert(arr, t, pos);
    return pos;
}

// Función arraySort
template<typename T>
void arraySort(Array<T>& arr, int cmpTT(T, T)) {
    for (int i = 0; i < arr.size - 1; i++) {
        for (int j = i + 1; j < arr.size; j++) {
            if (cmpTT(arr.data[i], arr.data[j]) > 0) {
                T temp = arr.data[i];
                arr.data[i] = arr.data[j];
                arr.data[j] = temp;
            }
        }
    }
}

// Función arrayDiscover
template<typename T>
Array<T> arrayDiscover(Array<T>& arr) {
    Array<T> newArray = array<T>(arr.size);
    for (int i = 0; i < arr.size; i++) {
        arrayAdd(newArray, arr.data[i]);
    }
    return newArray;
}

#endif // ARRAY_HPP
