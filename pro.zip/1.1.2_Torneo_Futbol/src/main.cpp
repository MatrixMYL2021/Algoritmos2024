#include <iostream>
//#include <sstream>
#include <string>
#include <string.h>
#include <stdlib.h>
#include "biblioteca/funciones/strings.hpp"
#include "biblioteca/funciones/files.hpp"
#include "biblioteca/funciones/tokens.hpp"
#include "biblioteca/tads/colldiscord.hpp"
#include "main.hpp"
#include <fstream>
using namespace std;


int main() {


	FILE* archivo = fopen("EQUIPOS.dat","r+b");
	Equipo x= read<Equipo>(archivo);
	while(!feof(archivo)){
		cout<<equipoToDebug(x)<<endl;
		x=read<Equipo>(archivo);
	}
	fclose(archivo);

	cout<<"---------------------"<<endl;

	FILE* archivo2= fopen("RESULTADOS.dat","r+b");
	Resultado x2=read<Resultado>(archivo2);
	while(!feof(archivo2)){
		cout<<resultadoToDebug(x2)<<endl;
		x2=read<Resultado>(archivo2);
	}
	fclose(archivo2);



    return 0;

}
