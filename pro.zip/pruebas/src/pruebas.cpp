#include <iostream>
#include <map>
using namespace std;

int main(){

	map<string,int> edadmap;

	edadmap["Matias"]=22;
	edadmap["Brisa"]=19;
	edadmap["Melisa"]=15;
	edadmap["Gabriel"]=13;
	edadmap["Adrian"]=12;

	//cout<<"La edad de Brisa es: "<<edadmap["Adrian"]<<endl;

	for(const auto& x:edadmap){
		cout<<x.first<<": "<<x.second<<endl;
	}

	return 0;
}




