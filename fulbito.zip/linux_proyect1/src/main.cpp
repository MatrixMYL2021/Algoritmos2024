#include "biblioteca/funciones/files.hpp"
#include "biblioteca/funciones/arrays.hpp"
#include "biblioteca/funciones/strings.hpp"
#include "biblioteca/funciones/tokens.hpp"
#include "biblioteca/tads/Arrays.hpp"
#include "biblioteca/tads/colldiscord.hpp"
#include "biblioteca/tads/Map.hpp"
#include <iostream>
#include <map>
#include <tuple>
#include "main.hpp"
using namespace std;


map<int, Equipos> mapEquipos;       // Mapea idEq -> información del equipo
map<int, Resultado> mapResultados;  // Mapea codRes -> resultado

// Función para cargar los equipos desde el archivo "EQUIPOS.dat"
void cargarEquipos() {
    ifstream file("EQUIPOS.dat", ios::binary);
    if (!file) {
        cerr << "Error al abrir EQUIPOS.dat" << endl;
        return;
    }

    Equipos equipo;
    while (file.read(reinterpret_cast<char*>(&equipo), sizeof(Equipos))) {
        mapEquipos[equipo.idEq] = equipo;
    }

    file.close();
}
// Función para cargar los resultados desde el archivo "RESULTADOS.dat"
void cargarResultados() {
    ifstream file("RESULTADOS.dat", ios::binary);
    if (!file) {
        cerr << "Error al abrir RESULTADOS.dat" << endl;
        return;
    }

    Resultado resultado;
    while (file.read(reinterpret_cast<char*>(&resultado), sizeof(Resultado))) {
        // Mapear el resultado usando el codRes como clave
        mapResultados[resultado.idEq1] = resultado;
    }

    file.close();
}



void viewstadiums(){

    cout<<"Estadios : \n"<<endl;

    for(const auto& [codRes, resultado] : mapResultados){
        cout<<resultado.estadio<<endl;
    }
}
void teaminfo(int x){
	if(mapEquipos.find(x)!=mapEquipos.end()){
		Equipos equipo = mapEquipos[x];

		cout<<"id: "<<equipo.idEq<<
			"| nombre: "<<equipo.nombre<<
			"| puntos: "<<equipo.puntos<<endl;
	}else{cout<<"Lo lamento pero su id buscado no existe !"<<endl;}
}
void ejercicio1(){
    vector<pair<int,Equipos>> eqVector(mapEquipos.begin(),mapEquipos.end());

    sort(eqVector.begin(), eqVector.end(), [](const pair<int,Equipos>& a, const pair<int,Equipos>& b){
            return a.second.puntos > b.second.puntos;
        }
    );

    cout<<"\nTabla de posiciones: (Ejercicio 1)\n"<<endl;
    for(const auto& [idEq, equipo]: eqVector){
        cout<<equipo.nombre<<"- "<<equipo.puntos<<" pts."<<endl;
    }
}
void ejercicio2(){}



int main() {

    cargarEquipos();
    cargarResultados();
    ejercicio1();


    /*FILE* f=fopen("RESULTADOS.dat","r+b");
    Resultado x =read<Resultado>(f);

    while(!feof(f)){
    	cout<<resultadoToDebug(x)<<endl;
    	x=read<Resultado>(f);
    }

    fclose(f);*/

    return 0;
}
