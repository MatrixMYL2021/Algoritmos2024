#include "biblioteca/funciones/files.hpp"
#include "biblioteca/funciones/arrays.hpp"
#include "biblioteca/funciones/strings.hpp"
#include "biblioteca/funciones/tokens.hpp"
#include "biblioteca/tads/Arrays.hpp"
#include "biblioteca/tads/colldiscord.hpp"
#include "biblioteca/tads/Map.hpp"
#include <iostream>
#include <map>
#include <tuple>
#include "main.hpp"
using namespace std;

// Definición de mapas para almacenar los equipos y los resultados
map<int, Equipos> mapEquipos;       // Mapea idEq -> información del equipo
map<int, Resultado> mapResultados;  // Mapea codRes -> resultado

// Función para cargar los equipos desde el archivo "EQUIPOS.dat"
void cargarEquipos() {
    ifstream file("EQUIPOS.dat", ios::binary);
    if (!file) {
        cerr << "Error al abrir EQUIPOS.dat" << endl;
        return;
    }

    Equipos equipo;
    while (file.read(reinterpret_cast<char*>(&equipo), sizeof(Equipos))) {
        mapEquipos[equipo.idEq] = equipo;
    }

    file.close();
}

// Función para cargar los resultados desde el archivo "RESULTADOS.dat"
void cargarResultados() {
    ifstream file("RESULTADOS.dat", ios::binary);
    if (!file) {
        cerr << "Error al abrir RESULTADOS.dat" << endl;
        return;
    }

    Resultado resultado;
    while (file.read(reinterpret_cast<char*>(&resultado), sizeof(Resultado))) {
        // Mapear el resultado usando el codRes como clave
        mapResultados[resultado.idEq1] = resultado;
    }

    file.close();
}

// Función para mostrar los equipos cargados
void mostrarEquipos() {
    for (const auto& [idEq, equipo] : mapEquipos) {
        cout << "Id: " << idEq << "| name: " << equipo.nombre << "| points: " << equipo.puntos << endl;
    }
}

// Función para mostrar los resultados cargados
void mostrarResultados() {
    for (const auto& [codRes, resultado] : mapResultados) {
        cout << "Resultado: " << codRes
             << " Partido entre equipo " << resultado.idEq1
             << " y equipo " << resultado.idEq2
             << " en el estadio: " << resultado.estadio << endl;
    }
}

void viewstadiums(){

    cout<<"Estadios : \n"<<endl;

    for(const auto& [codRes, resultado] : mapResultados){
        cout<<resultado.estadio<<endl;
    }
}

int main() {
    // Cargar los equipos y resultados desde los archivos .dat
    cargarEquipos();
    cargarResultados();

    // Mostrar equipos y resultados
    //cout << "Equipos cargados:" << endl;
    //mostrarEquipos();

    viewstadiums();

    //cout << "\nResultados cargados:" << endl;
    //mostrarResultados();



    return 0;
}
